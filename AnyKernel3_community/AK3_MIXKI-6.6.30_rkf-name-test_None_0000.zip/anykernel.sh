#!/sbin/sh
kernel.string=Test
