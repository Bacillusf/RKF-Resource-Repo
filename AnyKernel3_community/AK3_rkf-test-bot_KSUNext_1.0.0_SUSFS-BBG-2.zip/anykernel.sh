#!/sbin/sh
# AnyKernel3 test
kernel.string=TestKernel
